#
#run config/ip_pipeline.sh
#

p 1 ping
